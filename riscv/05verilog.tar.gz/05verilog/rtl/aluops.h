
`ifndef ALUOPS_H
`define ALUOPS_H 1

`define OP_ADD   2'd0
`define OP_SUB   2'd1
`define OP_SHIFT 2'd2

`endif

